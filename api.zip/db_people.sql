-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 28 Nov 2018 pada 14.17
-- Versi Server: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_people`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_name`
--

CREATE TABLE IF NOT EXISTS `tb_name` (
`id` int(20) NOT NULL,
  `name` text
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data untuk tabel `tb_name`
--

INSERT INTO `tb_name` (`id`, `name`) VALUES
(1, 'Asuka Tenjouin'),
(2, 'Judai Yuki'),
(3, 'Jun Manjoume'),
(4, 'Misawa Daichi'),
(5, 'Sho Marufuji'),
(6, 'Ryo Marufuji'),
(7, 'Atem'),
(8, 'Yugi Mutou'),
(9, 'Hayato Maeda'),
(10, 'Uzumaki Naruto'),
(11, 'Sora Amamiya'),
(12, 'Edy Kobayashi'),
(13, 'Haruka Tomatsu'),
(14, 'Asuka Yuki'),
(15, 'Kiri Tongkol'),
(16, 'Takashi Minami');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_name`
--
ALTER TABLE `tb_name`
 ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_name`
--
ALTER TABLE `tb_name`
MODIFY `id` int(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=17;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
