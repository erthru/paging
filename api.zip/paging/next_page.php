<?php

    error_reporting(0);
    require_once('connect.php');

    $last_id = $_GET['last_id'];

    if(!$last_id){
        echo json_encode(array('result'=>'bad request'));
    }else{
        $result = null;

        $query = mysqli_query($con,"SELECT * FROM tb_name WHERE id < $last_id ORDER BY id DESC LIMIT 5");
        while($row = mysqli_fetch_assoc($query)){
           $result[] = $row;
        }


        echo json_encode(array('result'=>$result));
    }


?>