<?php

    require_once('connect.php');

    $result = null;

    $query = mysqli_query($con,"SELECT * FROM tb_name ORDER BY id DESC LIMIT 10");
    while($row = mysqli_fetch_assoc($query)){
        $result[] = $row;
    }


    echo json_encode(array('result'=>$result));


?>